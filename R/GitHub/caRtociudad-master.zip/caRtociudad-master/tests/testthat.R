library(testthat)
library(caRtociudad)

test_check("caRtociudad")
