# KSCHOOL-DATASCIENCE-R_LIBMAD_1
R practice with Madrid public libraries data

R reshape2 and plyr libraries practice with datos.madrid.es data of public libraries book check-outs: finding the most checked-out book and author
